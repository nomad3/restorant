<?php
// Start the session
session_start();
include 'config.php';
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $conf['appName'] ?></title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- jVectorMap -->
    <link href="css/maps/jquery-jvectormap-2.0.3.css" rel="stylesheet"/>



    <!-- Costume -->
    <link href="css/costume.css" rel="stylesheet"/>



    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">

  </head>

  <body class="nav-md">

    <!-- Common body -->
    <?php include 'commonbody.php';?>
    <!-- /Common body -->


    <div class="row">
      <div class="col-md-12">
        <h1><?= $SETTINGS['appName'] ?></h1>
        <hr />
        <p>This is the initial page of your admin pannel.<br />You can extend it with your desired functionality or shortcuts</p>
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
        <br /><br /><br />
      </div>



    </div>

  </div>
  <!-- /page content -->

  <!-- footer content -->
  <footer>
    <div class="pull-right">
      <?= $conf->appName ?>
    </div>
    <div class="clearfix"></div>
  </footer>
  <!-- /footer content -->
</div>
</div>





<!-- jQuery -->
<script src="vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="vendors/nprogress/nprogress.js"></script>
<!-- gauge.js -->
<script src="vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>

<!-- bootstrap-daterangepicker -->
<script src="js/moment/moment.min.js"></script>
<script src="js/datepicker/daterangepicker.js"></script>

<!-- Custom Theme Scripts -->
<script src="build/js/custom.min.js"></script>

    <!-- Settings -->
    <script src="settings.js"></script>

    <!-- FIREBASE -->
    <script src="https://www.gstatic.com/firebasejs/3.5.3/firebase.js"></script>
    <script type="text/javascript">
    // Initialize Firebase
    var config = {
      apiKey: settings.apiKey,
      authDomain: settings.authDomain,
      databaseURL: settings.databaseURL,
      storageBucket: settings.storageBucket,
      messagingSenderId: settings.messagingSenderId
    };
    firebase.initializeApp(config);

    //Check login status
    firebase.auth().onAuthStateChanged(function(user) {
      if (user) {
        // User is signed in.
          console.log("User is signed in.");
          $('.theUser').html(user.email);
      } else {
        // No user is signed in.
          console.log("No user is signed in.");
          window.location.replace("login.php");
      }
    });

    </script>
    <!-- /FIREBASE -->


    <script>
      /*
      *
      *  JQUERY Start
      *
      */
      $( document ).ready(function() {
        //Hide loader
        $('#loader').hide();
      });
    </script>

  </body>
</html>
