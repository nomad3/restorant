<?php
// Start the session
session_start();
include 'config.php';

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $SETTINGS['appName'] ?></title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://colorlib.com/polygon/gentelella/css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="login.php" method="post">
              <h1>Login Form</h1>
              <p id="error" style="color:red"></p>
              <div>
                <input id="username" type="text" class="form-control" placeholder="Username" required="" />
              </div>
              <div>
                <input id="password" type="password" class="form-control" placeholder="Password" required="" />
              </div>
              <div>
                <a  id="btnLogin" class="btn btn-default submit">Log in</a>

              </div>

              <div class="clearfix"></div>

              <div class="separator">


                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-braille"></i> <?= $SETTINGS['appName'] ?>!</h1>
                  <p>©2016 All Rights Reserved</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
  </body>

  <!-- jQuery -->
  <script src="vendors/jquery/dist/jquery.min.js"></script>

  <script src="settings.js"></script>

  <!-- FIREBASE -->
  <script src="https://www.gstatic.com/firebasejs/3.5.3/firebase.js"></script>

  <script>
    // Initialize Firebase
    var config = {
      apiKey: settings.apiKey,
      authDomain: settings.authDomain,
      databaseURL: settings.databaseURL,
      storageBucket: settings.storageBucket,
      messagingSenderId: settings.messagingSenderId
    };
    firebase.initializeApp(config);


    $( document ).ready(function() {
      $('#btnLogin').click(function(e){


        firebase.auth().signInWithEmailAndPassword($('#username').val(), $('#password').val())
        .then(
          function(data) {
            window.location.replace("index.php");
          }
        )
        .catch(function(error) {
          // Handle Errors here.
          var errorCode = error.code;
          var errorMessage = error.message;
          $('#error').html(errorMessage)
        });

      })
    });
  </script>

</html>
