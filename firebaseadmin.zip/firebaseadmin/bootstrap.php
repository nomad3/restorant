<!-- Bootstrap Table -->
<div style="visibility: collapse; display:none">
  <div id="tableBootstrap" class="col-md-12 col-sm-12 col-xs-12">
    <div class="x_panel">
      <div class="x_title">
        <h2>Table name</h2>
        <ul class="nav navbar-right panel_toolbox">
          <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
          <li><a class="addArrayElement" id="addArrayElement"  ><i class="fa fa-plus"></i></a></li>
        </ul>
        <div class="clearfix"></div>
      </div>
      <div class="x_content">

        <table id="datatable" class="table table-striped table-bordered">
              <thead>
                <tr>
                  <th>Element</th>

                </tr>
              </thead>


              <tbody>

              </tbody>
          </table>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap Fields -->
<div id="fieldsHolder" style="display:none" class="col-md-12 col-sm-12 col-xs-12">
  <div class="x_panel">
    <div class="x_title">
      <h2>Fields</h2>
      <ul class="nav navbar-right panel_toolbox">
        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
        <li><a id="addNewItem"  data-toggle="modal" data-target="#myModal" ><i class="fa fa-plus"></i></a></li>
      </ul>
      <div class="clearfix"></div>
    </div>
    <div class="x_content">
      <br>
      <form id="firebaseForm" data-parsley-validate="" class="form-horizontal form-label-left" novalidate="">

        <!-- Bootstrap IMAGE element -->
        <div style="visibility: collapse; display:none">
            <div class="form-group" id="bootstrapPhotoElement">
              <label for="imageFieldId" class="control-label col-md-3 col-sm-3 col-xs-12">Element name</label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-new thumbnail" >
                          <img id="previewImageID" src="https://placeholdit.imgix.net/~text?w=300&h=200&txt=Select%20your%20image&txtclr=000000&txtsize=25&bg=efefef" alt="" />
                      </div>
                      <div class="fileupload-preview fileupload-exists thumbnail" ></div>
                      <div>
                                 <span class="btn btn-white btn-file">
                                 <span class="fileupload-new"><i class="fa fa-paper-clip"></i> Select image</span>
                                 <span class="fileupload-exists"><i class="fa fa-undo"></i> Change</span>
                                 <input type="file" id="photoID" class="default" />
                                 </span>
                          <a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload"><i class="fa fa-trash"></i> Remove</a>
                      </div>
                  </div>

              </div>
              <div class="col-md-1 col-sm-1 col-xs-12">
                <div><a class="btn btn-danger deleteElement" id="deleteID"><i class="fa fa-trash"></i></a></div>
              </div>

              <div id="loaderID" class="col-md-2 col-sm-2 col-xs-12"></div>
          </div>
        </div>

        <!-- Bootstrap TEXT FIELD element -->
        <div style="visibility: collapse; display:none">
          <div class="form-group" id="bootstrapElement">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="element">Element name</label>
            <div class="col-md-6 col-sm-6 col-xs-12">
              <input type="text" id="elementID" value=""; class="form-control col-md-7 col-xs-12">
            </div>
            <div class="col-md-1 col-sm-1 col-xs-12">
              <div><a class="btn btn-danger deleteElement" id="deleteID"><i class="fa fa-trash"></i></a></div>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-12">
              <div id="loaderID"></div>
            </div>
          </div>
        </div>


        <!-- Bootstrap SELECT element -->
        <div style="visibility: collapse; display:none">
          <div class="form-group" id="bootstrapSelectElement">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="element">Element name</label>
            <div class="col-md-6 col-sm-6 col-xs-12">

              <select  id="elementID" class="form-control col-md-7 col-xs-12">

              </select>
            </div>
            <div class="col-md-1 col-sm-1 col-xs-12">
              <div><a class="btn btn-danger deleteElement" id="deleteID"><i class="fa fa-trash"></i></a></div>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-12">
              <div id="loaderID"></div>
            </div>
          </div>
        </div>




      </form>
    </div>
  </div>
</div>
