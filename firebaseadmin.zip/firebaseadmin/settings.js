var settings={
  "appName": "Restaurant admin",
  "codeversion": "1.0",
  "apiKey": "YOUR API KEY",
  "authorizationPushKey": "YOUR API KEY",
  "authDomain": "YOUR DOMAIN",
  "databaseURL": "YOUR DB URL",
  "storageBucket": "YOUR BUCKET",
  "messagingSenderId": "SENDER ID",
  "photoFields":["photo"],
  "dropdowns":["status"],
  "dropdownOptions":[{"key":"status","options":["new","processing","rejected","completed"]}],
  "pushTopics":["promo","news"],
  "menu": [
    {
      "link": "index.php",
      "name": "Dashboard",
      "schema":null,
      "icon":"home"
    },
    {
      "link": "firebase.php",
      "path": "Categories",
      "name": "Menu",
      "schema":{"items":[{"name":"Category name","description":"Category description","photo":"","items":[{"description":"Item description","info":{"Calories":""},"name":"Item name","photo":"","price":"12.00 $","prices":[{"price_info":"Price info","price_name":"Price name","price_value":"12"}]}]}]},
      "icon":"list-alt",
      "tableFields":["name","description"],
      "prefixForJoin":{}
    },
    {
      "link": "firebase.php",
      "path": "Orders",
      "name": "Orders",
      "schema":null,
      "icon":"cart-arrow-down",
      "tableFields":["name","status","price","date"],
      "prefixForJoin":{"-KW":"orders"}
    },
    {
      "link": "push.php",
      "name": "Push Notifications",
      "schema":null,
      "icon":"bullhorn"
    }
  ]
}
