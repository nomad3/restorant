import React, {StyleSheet, Dimensions, PixelRatio} from "react-native";
const {width, height, scale} = Dimensions.get("window"),
    vw = width / 100,
    vh = height / 100,
    vmin = Math.min(vw, vh),
    vmax = Math.max(vw, vh);

export default StyleSheet.create({
    "loader": {
        "border": "8px solid #E8E9E8",
        "borderTop": "8px solid #1F2F43",
        "borderRadius": "50%",
        "width": 60,
        "height": 60,
        "animation": "spin 1.5s linear infinite"
    },
    "loaderSmall": {
        "border": "5px solid #E8E9E8",
        "borderTop": "5px solid #1F2F43",
        "borderRadius": "50%",
        "width": 30,
        "height": 30,
        "animation": "spin 1.5s linear infinite"
    }
});