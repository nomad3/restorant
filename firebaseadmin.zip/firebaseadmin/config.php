<?php


  /**
  * Get settings from settings.js
  */
  $myfile = fopen("settings.js", "r") or die("Unable to open file!");
  $jsonSettings="";
  while(!feof($myfile)) {
    $jsonSettings.=fgets($myfile);
  }

  $jsonSettings = str_replace("var settings=", "", $jsonSettings);
  $SETTINGS=json_decode($jsonSettings,true);
  $conf=$SETTINGS;
  fclose($myfile);



?>
