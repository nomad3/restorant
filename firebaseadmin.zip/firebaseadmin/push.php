<?php
// Start the session
session_start();
include 'config.php';

$sendPush=false;
if(isset($_POST['pushText'])&&isset($_POST['pushTopic'])&&$_POST['pushTopic'].""!="0"){
  $sendPush=true;

  $url = 'https://fcm.googleapis.com/fcm/send';
  $json = '{
    "to":"'.$_POST['pushTopic'].'",
    "notification": {
      "body":"'.$_POST['pushText'].'",
    },
    "priority":10,
  }';

  // use key 'http' even if you send the request to https://...
  $options = array(
      'http' => array(
          'header'  => "Content-type: application/json  Authorization:key=".$SETTINGS['authorizationPushKey']."\r\n",
          'method'  => 'POST',
          'content' => $json
      )
  );
  $context  = stream_context_create($options);
  $result = file_get_contents($url, false, $context);



}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $conf['appName'] ?></title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- jVectorMap -->
    <link href="css/maps/jquery-jvectormap-2.0.3.css" rel="stylesheet"/>



    <!-- Costume -->
    <link href="css/costume.css" rel="stylesheet"/>



    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">

  </head>

  <body class="nav-md">

    <!-- Common body -->
    <?php include 'commonbody.php';?>
    <!-- /Common body -->


    <div class="row">
      <div class="col-md-12">
        <h1>Push notifications</h1>
        <p>Send push to your app users</p>
        <hr />
      </div>
    </div>

    <div class="x_panel">

      <div class="x_title">
        <h2>Simple push</h2>
        <div class="clearfix"></div>
      </div>

      <div class="col-md-6">
        <form method="POST">

        <!-- Message text -->
        <div class="form-group col-md-12" id="bootstrapElement">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="element">Message text</label>
          <div class="col-md-9 col-sm-9 col-xs-12">
            <input type="text" placeholder="Enter message" name="pushText" value=""; class="form-control col-md-7 col-xs-12">
          </div>
        </div>
        <br />

        <!-- Message topic -->
        <div class="form-group col-md-12" id="bootstrapSelectElement">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="element">Push topic</label>
          <div class="col-md-9 col-sm-9 col-xs-12">


            <select  name="pushTopic" class="form-control col-md-7 col-xs-12">
              <option value="0">Select topic</option>
              <?php
                foreach ($SETTINGS['pushTopics'] as $key => $value) {
                  echo "<option value=".$value.">".ucfirst($value)."</option>";
                }
              ?>
            </select>
          </div>


        </div>


        <!-- Send button -->
        <div class="form-group col-md-12">

          <div class=" pull-right">
            <button type="send" class="btn btn-danger">Send push now</button>
          </div>
        </div>
      </form>
      </div>

      <div class="col-md-6">
        <p>Send push to selected topic</p>
        <?php
          if($sendPush){
            if ($result === FALSE) {
              echo "<p><strong>Error on push</strong></p><br />";
              print_r($result);
            }else{
              echo "<p><strong>Push send</strong></p>";
            }
          }
        ?>
      </div>




    </div>

    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />
    <br /><br /><br />

  </div>
  <!-- /page content -->

  <!-- footer content -->
  <footer>
    <div class="pull-right">
      <?= $conf->appName ?>
    </div>
    <div class="clearfix"></div>
  </footer>
  <!-- /footer content -->
</div>
</div>





<!-- jQuery -->
<script src="vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="vendors/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="vendors/nprogress/nprogress.js"></script>
<!-- gauge.js -->
<script src="vendors/gauge.js/dist/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>

<!-- bootstrap-daterangepicker -->
<script src="js/moment/moment.min.js"></script>
<script src="js/datepicker/daterangepicker.js"></script>

<!-- Custom Theme Scripts -->
<script src="build/js/custom.min.js"></script>


    <!-- Settings -->
    <script src="settings.js"></script>

    <!-- FIREBASE -->
    <script src="https://www.gstatic.com/firebasejs/3.5.3/firebase.js"></script>
    <script type="text/javascript">
    // Initialize Firebase
    var config = {
      apiKey: settings.apiKey,
      authDomain: settings.authDomain,
      databaseURL: settings.databaseURL,
      storageBucket: settings.storageBucket,
      messagingSenderId: settings.messagingSenderId
    };
    firebase.initializeApp(config);

    //Check login status
    firebase.auth().onAuthStateChanged(function(user) {
      if (user) {
        // User is signed in.
          console.log("User is signed in.");
          $('.theUser').html(user.email);
      } else {
        // No user is signed in.
          console.log("No user is signed in.");
          window.location.replace("login.php");
      }
    });

    </script>
    <!-- /FIREBASE -->

    <script>
      /*
      *
      *  JQUERY Start
      *
      */
      $( document ).ready(function() {
        //Hide loader
        $('#loader').hide();
      });
    </script>

  </body>
</html>
