
<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
  <div class="menu_section">
    <h3></h3>
    <ul class="nav side-menu">
      <?php
      $index=0;
      foreach ($conf['menu'] as $key => $value) {
        echo '<li><a href="'.$value['link'].'?path='.$value['path'].'&index='.$index.'"><i class="fa fa-'.$value['icon'].'"></i> '.$value['name'].'</a></li>';
        $index++;
      }
      ?>
    </ul>
  </div>

</div>
