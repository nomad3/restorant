<div class="container body">
  <div class="main_container">
    <div class="col-md-3 left_col">
      <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
          <a href="index.php" class="site_title"><span><?= $conf['appName'] ?></span></a>
        </div>

        <div class="clearfix"></div>

        <!-- menu profile quick info -->
        <div class="profile">

        </div>
        <!-- /menu profile quick info -->

        <br />

        <!-- sidebar menu -->
        <?php include 'menu.php';?>
        <!-- /sidebar menu -->

        <!-- /menu footer buttons -->
        <div class="sidebar-footer hidden-small">

          <a id="logoutBtn" data-toggle="tooltip" data-placement="top" title="Logout">
            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
          </a>
        </div>
        <!-- /menu footer buttons -->
      </div>
    </div>

    <!-- top navigation -->
    <div class="top_nav">
      <div class="nav_menu">
        <nav class="" role="navigation">
          <div class="nav toggle">
            <a id="menu_toggle"><i class="fa fa-bars"></i></a>
          </div>

          <ul class="nav navbar-nav navbar-right">
            <li class="">
              <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                <span class="theUser"></span>
                <span class=" fa fa-angle-down"></span>
              </a>
              <ul class="dropdown-menu dropdown-usermenu pull-right">

                <li><a href="login.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
              </ul>
            </li>


          </ul>
        </nav>
      </div>
    </div>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">


      <!-- Breadcrumbs -->
      <div class="breadcrumbs"  style="display:none" class="row">
        <div class="col-md-6">
          <ol class="breadcrumb">
            <?php
              $path=$_GET['path'];
              $blocks=explode("/",$path);
              $before="";
              foreach ($blocks as $key => $value) {
                $link=$before==""?$value:$before."/".$value;


                echo '<li><a href="firebase.php?index='.$_GET['index'].'&path='.$link.'">'.ucfirst($value).'</a></li>';
                $before==""?$before.=$value:$before.="/".$value;
                //echo $before."</br />";

              }

              $screenName= is_numeric($blocks[sizeof($blocks)-1]) ? $blocks[sizeof($blocks)-2]:$blocks[sizeof($blocks)-1];
              $screenNameOriginal=$screenName;
              $screenName=ucfirst($screenName);
            ?>
          </ol>
        </div>
        <div class="col-md-6">
          <div class="col-md-8">
          </div>
          <div class="col-md-4">
            <div><a class="btn btn-danger deleteObject" id="deleteObject"><i class="fa fa-trash"> <span style="font-family: Helvetica Neue,Helvetica,Arial,sans-serif;" >Delte this item</span></i></a></div>
          </div>
        </div>
      </div>

      <!-- Loader -->
      <div class="row" id="loader">
        <div class="col-md-2 col-md-offset-5">
          <div class="loader"></div>
        </div>
      </div>

      
