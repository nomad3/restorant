//Capitalize
String.prototype.ucfirst = function() {
    return (this.charAt(0).toUpperCase() + this.slice(1)).replace("_"," ");
}

/**
* Prepares image for firebase, turns it to base 64
*/
function encodeImageFileAsURL(name) {
  var id="photo_"+name;
  console.log(id);
  var filesSelected = document.getElementById(id).files;
  if (filesSelected.length > 0) {
    var fileToLoad = filesSelected[0];

    var fileReader = new FileReader();

    fileReader.onload = function(fileLoadedEvent) {
      var srcData = fileLoadedEvent.target.result; // <--- data: base64
      uploadFileToFirebase(name,srcData);
    }
    fileReader.readAsDataURL(fileToLoad);
  }
}


/*
*
*    BOOTSTRAPING ELEMENTS
*
*/
/**
* Add field - Decider what to display
*/
function addBootstrapField(name,value){

  //Check if it is photo
  if(settings.photoFields.indexOf(name)>-1){
    //This is photo
    addImageField(name,value);
  }
  else if(settings.dropdowns.indexOf(name)>-1){
    //This is drop down
    addSelectorField(name,value);
  }else{
    //This is text field
    addTextField(name,value);
  }
}

/*
* Select - Drop down element
*/
function addSelectorField(name,value){
    $('#fieldsHolder').show();
    var clonedElement=$( "#bootstrapSelectElement" ).clone();
    clonedElement.find( "label" ).html(name.ucfirst());
    clonedElement.find( "#loaderID" ).prop('id', 'loader'+name );
    clonedElement.find( "#elementID" ).prop('id', 'element'+name );
    clonedElement.find( "#deleteID" ).prop('id', 'delete'+name );
    clonedElement.find( "select" ).change(function(e) { writeTFData(name, this.value) });

    var options=[];
    for(var i=0;settings.dropdownOptions&&i<settings.dropdownOptions.length;i++){
      if(settings.dropdownOptions[i].key==name){
        options=settings.dropdownOptions[i].options;

      }
    }

    for(var i=0;i<options.length;i++){
      var itemToAdd=$("<option />").val(options[i]).text((options[i]+"").ucfirst());
      if(value==options[i]){
        itemToAdd.prop('selected',true);
      }
      clonedElement.find( "#element"+name ).append(itemToAdd);
    }


    clonedElement.appendTo( "#firebaseForm" );


}

/**
* Adds text field
*/
function addTextField(name,value){
  $('#fieldsHolder').show();
  var clonedElement=$( "#bootstrapElement" ).clone();
  clonedElement.find( "label" ).html(name.ucfirst());
  clonedElement.find( "input" ).val(value);
  clonedElement.find( "input" ).change(function(e) { writeTFData(name, this.value) });
  clonedElement.find( "#loaderID" ).prop('id', 'loader'+name );
  clonedElement.find( "#elementID" ).prop('id', 'element'+name );
  clonedElement.find( "#deleteID" ).prop('id', 'delete'+name );


  clonedElement.appendTo( "#firebaseForm" );
}

/**
* Add image picker
*/
function addImageField(name,value){
  var clonedElement=$( "#bootstrapPhotoElement" ).clone();
  clonedElement.find( "label" ).html(name.ucfirst());
  if(value&&(value+"").length>5){
    clonedElement.find( "#previewImageID" ).prop('src', value );
  }
  clonedElement.find( "#loaderID" ).prop('id', 'loader'+name );
  clonedElement.find( "#photoID" ).prop('id', 'photo_'+name );
  clonedElement.find( "#deleteID" ).prop('id', 'delete'+name );


  clonedElement.find( "input" ).change(function(e) {
    //writeTFData(name, this.value) ;
    encodeImageFileAsURL(name);
  });


  clonedElement.appendTo( "#firebaseForm" );
}

/*
* Adds table
*/
function addTable(name,items,normal){
  console.log(name+": "+normal)

  var clonedElement=$( "#tableBootstrap" ).clone();
  clonedElement.find( "h2" ).html(name.ucfirst());
  clonedElement.find( "table" ).prop('id', 'datatable'+name );
  if(schema){
    clonedElement.find( ".addArrayElement" ).prop('id', 'addArrayElement'+name );
  }else{
    clonedElement.find( ".addArrayElement" ).hide();
  }

  clonedElement.find( ".addArrayElement" ).on('click', function () {
    appendArrayElement(name);

    //console.log(ourFirebaseData);
  });


  //Find the headers
  var headers=[];
  if(items&&items.length>0){
    //First element
    var elementOfInterest=items[0];

    desiredHeaders=settings.menu[menuIndex].tableFields;
    for(var i=0;desiredHeaders&&i<desiredHeaders.length;i++){
      if(elementOfInterest&&elementOfInterest.hasOwnProperty(desiredHeaders[i])){
        headers.push(desiredHeaders[i]);
      }
    }

    //Continue with avaialbe ones
    if(headers.length==0){

      for (var key in elementOfInterest) {
        if (elementOfInterest.hasOwnProperty(key)){
          var obj=elementOfInterest[key];
          //TODO Don't add photos
          if(Object.prototype.toString.call( obj )==='[object String]'&&headers.length<4){
            //Add this one
            headers.push(key);
          }
        }
      }
    }
  }

  console.log(headers);

  //Add this in the table
  var headerValue="";
  for(var i=0;i<headers.length;i++){
    headerValue+="<th>"+headers[i].ucfirst()+"</th>";
  }
  headerValue+="<th>Action</th>";

  clonedElement.find( "table" ).find("thead").find("tr").html(headerValue);



  clonedElement.appendTo( "#tableHolder" );

  var t=$('#datatable'+name).DataTable({

  });


  //Add the rows
  for(var i=0;i<items.length;i++){
    var row=[];
    for(var j=0;j<headers.length;j++){
      row.push(items[i][headers[j]]?items[i][headers[j]]:"");

    }
    if(normal){
      row.push('<a href="firebase.php?index='+menuIndex+'&path='+path+'/'+name+'/'+i+'">View</a>');
    }else{
      if(typeObjReceived==='[object Array]'){
        row.push('<a href="firebase.php?index='+menuIndex+'&path='+path+'/'+i+'">View</a>');
      }else{

        row.push('<a href="firebase.php?index='+menuIndex+'&path='+path+'/'+objectListKey[name][i]+'">View</a>');
      }

    }
    t.row.add(row).draw( true );
  }
}


/*
*
*  FIREBASE ACTIONS
*
*/

/**
* Uploads file to firebase
*/
function uploadFileToFirebase(name,value){
  //Upload file to firebase
  console.log("Upload file to firebase");

  //Show his loader
  $("#loader"+name).addClass('loaderSmall');

  // Create a root reference
  var storageRef = firebase.storage().ref();


  var refFile=new Date().getTime()+".jpg"

  // Create a reference to 'mountains.jpg'
  var newImageRef = storageRef.child(refFile);
  var stripedImage=value.substring(value.indexOf('base64')+7, value.length);

  // Base64 formatted string
  newImageRef.putString(stripedImage, 'base64').then(function(snapshot) {
    console.log('Uploaded a base64 string!');
    writeTFData(name,snapshot.downloadURL);
  });
}

/**
* DELETE ITEM
*/
function deleteTheCurrentItem(){
  firebase.database().ref(path).remove().then(function(snapshot) {

    var callPath=path.substring(0,path.lastIndexOf("/"));
    var nextLocation=window.location.origin+window.location.pathname+"?index="+menuIndex+"&path="+callPath;
    window.location.replace(nextLocation);
  });
}

/**
* Updates the field data
*/
function writeTFData(name,value) {
  console.log("Update on "+name);
  console.log(JSON.stringify(value));

  //Show his loader
  $("#loader"+name).addClass('loaderSmall');
  console.log("Path "+path)
  var objToSave={}
  objToSave[name]=value;
  console.log(objToSave);
  firebase.database().ref(path).update(objToSave).then(function(snapshot) {
    // The Promise was "fulfilled" (it succeeded).
    //renderBlog(snapshot.val());
    console.log("Saved");
    $("#loader"+name).removeClass('loaderSmall');
    if(value==null){
      location.reload();
    }
    if(value==$('#newFieldValue').val()){
      location.reload();
    }
  }, function(error) {
    // The Promise was rejected.
    console.log("Error");
    console.error(error);
  });
}

/**
* Add missing elements based on the schema
*/
function appendArrayElement(name){
  console.log("Inserting "+name);
  console.log(myItem[name]);
  var itemToInsert=myItem[name];
  var isItArrayOurBootstrap=Object.prototype.toString.call( myItem )==="[object Array]";
  if(isItArrayOurBootstrap){
    itemToInsert=myItem;
  }
  indexToOpen=0;
  var objToSave={}
  var callPath=path
  if(ourFirebaseData[name]||isItArrayOurBootstrap){
    console.log("Append this element");

    indexToOpen=isItArrayOurBootstrap?ourFirebaseData.length:ourFirebaseData[name].length;
    callPath+="/"+name;
    if(isItArrayOurBootstrap){
      callPath=path;
    }
    objToSave[indexToOpen]=itemToInsert[0];
  }else{
    console.log("Create this new array");

    objToSave[name]=itemToInsert;

  }

  firebase.database().ref(callPath).update(objToSave).then(function(snapshot) {
    // The Promise was "fulfilled" (it succeeded).
    //renderBlog(snapshot.val());
    console.log("Saved");
    var nextLocation=isItArrayOurBootstrap?window.location.href+"/"+indexToOpen:window.location.href+"/"+name+"/"+indexToOpen;
    window.location.replace(nextLocation);
  }, function(error) {
    // The Promise was rejected.
    console.log("Error");
    console.error(error);
  });
}

/**
* Logout
*/
function signOut(){
  firebase.auth().signOut().then(
    function(data) {
      window.location.replace("login.php");
    }
  )
}

/*
*
*  FIREBASE FETCHER
*
*/
function getDataFromFirbase(){
  var fetcher = firebase.database().ref(path);
  fetcher.once('value', function(data) {
    var asVal=data.val();
    ourFirebaseData=asVal;

    typeObjReceived=Object.prototype.toString.call( asVal );
    console.log("ROOT OBJECT TYPE: "+typeObjReceived);

      //Hide loader
      $('#loader').hide();


      var objectList=[];

      for (var key in asVal) {
          // skip loop if the property is from prototype
          if (!asVal.hasOwnProperty(key)) continue;


          var obj = asVal[key];
          var typeObj=Object.prototype.toString.call( obj );

          //console.log("Key:"+key+" Tyepe:"+Object.prototype.toString.call( obj ));

          if(typeObj==='[object String]'||typeObj==='[object Number]'){
            console.log("Produce string "+key);
            addBootstrapField(key,obj);
          }
          if(typeObj==='[object Array]'){
            console.log("Produce array "+key);
            addedArrays+=key+",";
            addTable(key,obj,true);
          }
          if(typeObj==='[object Object]'){
            console.log("Add object in array :"+key);
            if(typeObjReceived==='[object Array]'){
              if(!objectList[screenNameOriginal]){
                objectList[screenNameOriginal]=[];
              }
              objectList[screenNameOriginal].push(obj);

              //Hide delete button
              $('#deleteObject').hide();

            }else{
              var realKey=key
              prefixForJoin=settings.menu[menuIndex].prefixForJoin;


              for (var prefix in prefixForJoin) {
                if (prefixForJoin.hasOwnProperty(prefix)) {

                  if(key.indexOf(prefix)==0){

                    key=prefixForJoin[prefix];

                  }
                }
              }

              if(!objectList[key]){
                objectList[key]=[];
              }
              objectList[key].push(obj);

              if(!objectListKey[key]){
                objectListKey[key]=[];
              }
              objectListKey[key].push(realKey);
            }

          }

          /*if( Object.prototype.toString.call( obj ) === '[object Array]' ) {
              console.log( 'Array!' );
          }

          console.log(obj);*/
          //console.log(obj)
          //console.log(Object.prototype.toString.call( obj ));

      }

      //Foreach object
      for (var keyOBL in objectList) {
          console.log(keyOBL+": before "+typeObjReceived);
          addTable(keyOBL,objectList[keyOBL],!typeObjReceived==='[object Array]');
      }
      /*if(objectList&&objectList.length>0){
        addTable(screenNameOriginal,objectList,false);
      }*/

      $('.deleteElement').on('click', function () {
        if(window.confirm("Are you sure?")){
          writeTFData(this.id.replace("delete",""),null);
        }else{
          console.log("no")
        }

      });

      if((path+"").indexOf("/")==-1){
        $('#deleteObject').hide();
      }

      $('.deleteObject').on('click', function () {
        if(window.confirm("Are you sure you want to delete complete object, including sub items?")){
          //writeTFData(this.id.replace("delete",""),null);
          deleteTheCurrentItem();
        }else{
          console.log("no")
        }

      });


    initialized=true;

    console.log("Added arrays: "+addedArrays);


    //Now check if we have some arrays to add
    if(myItem!=undefined){


      for (var key in myItem) {
          // skip loop if the property is from prototype
          if (!myItem.hasOwnProperty(key)) continue;


          var obj = myItem[key];
          var typeObj=Object.prototype.toString.call( obj );

          //console.log("Key:"+key+" Tyepe:"+Object.prototype.toString.call( obj ));

          if(typeObj==='[object Array]'){
            console.log("Check if exist "+key);
            if(addedArrays.indexOf(key)>-1){
              //it exists, add it to table
              console.log("Add it to the table")
            }else{
              console.log("Add it as new button")
              addTable(key,[],true);
            }

            //addTable(key,obj,true);
          }
        }
    }
  });

}
