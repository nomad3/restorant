<?php
// Start the session
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= $conf['appName'] ?></title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Image upload -->
    <link href="vendors/bootstrap-fileupload/bootstrap-fileupload.css" rel="stylesheet"/>

    <!-- Costume -->
    <link href="css/costume.css" rel="stylesheet"/>

    <!-- Datatables -->
    <link href="vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">


    <!-- Custom Theme Style -->
    <link href="build/css/custom.min.css" rel="stylesheet">




  </head>

  <body class="nav-md">

    <!-- Common body -->
    <?php include 'commonbody.php';?>
    <!-- /Common body -->


      <!-- Bootstrap Elements - Hidden initially -->
      <?php include 'bootstrap.php';?>

      <!-- The table holder -->
      <div id="tableHolder">
      </div>


    </div>
    <!-- /page content -->

    <!-- footer content -->
    <footer>
      <div class="pull-right">
        <?= $conf->appName ?>
      </div>
      <div class="clearfix"></div>
    </footer>
    <!-- /footer content -->
  </div>
  </div>


  <!-- Modal -->
  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add new field</h4>
      </div>
      <div class="modal-body">

        <div class="row" class="col-md-12">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="element">Field name</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="newFieldName" value=""; class="form-control col-md-7 col-xs-12">
          </div>

          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="newFieldLoaderID"></div>
          </div>
        </div>
        </div>

        <br />
        <div class="row">
        <div class="form-group">
          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="element">Field value</label>
          <div class="col-md-6 col-sm-6 col-xs-12">
            <input type="text" id="newFieldValue" value=""; class="form-control col-md-7 col-xs-12">
          </div>

          <div class="col-md-3 col-sm-3 col-xs-12">
            <div class="newFieldLoaderID"></div>
          </div>
        </div>
        </div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" id="addItem" class="btn btn-primary">Add field</button>
      </div>
    </div>
  </div>
  </div>


  <!-- jQuery -->
  <script src="vendors/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
  <!-- FastClick -->
  <script src="vendors/fastclick/lib/fastclick.js"></script>
  <!-- NProgress -->
  <script src="vendors/nprogress/nprogress.js"></script>
  <!-- gauge.js -->
  <script src="vendors/gauge.js/dist/gauge.min.js"></script>
  <!-- bootstrap-progressbar -->
  <script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>

  <!-- bootstrap-daterangepicker -->
  <script src="js/moment/moment.min.js"></script>
  <script src="js/datepicker/daterangepicker.js"></script>

  <!-- Custom Theme Scripts -->
  <script src="build/js/custom.min.js"></script>

  <!-- Datatables -->
  <script src="vendors/datatables.net/js/jquery.dataTables.min.js"></script>
  <script src="vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
  <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
  <script src="vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>

  <!-- Image upload -->
  <script src="vendors/bootstrap-fileupload/bootstrap-fileupload.js"></script>

  <!-- Settings -->
  <script src="settings.js"></script>


  <!-- Set UP -->
  <script type="text/javascript">
  var path="<?= $_GET['path'] ?>";
  var menuIndex="<?= $_GET['index'] ?>";
  var screenNameOriginal="<?= $screenNameOriginal ?>";
  var addedArrays="";
  var ourFirebaseData={};
  var schema=settings?settings.menu[menuIndex].schema:null;
  if(schema){
   var pathItems = path.split("/");
   var myItem=schema;
   for(var i=1;i<pathItems.length;i++){

     var key=pathItems[i];
     if(!isNaN(key)){
       key=0;
     }
     console.log(key)
     myItem=myItem[key];
   }
   console.log(myItem);
  }
  var initialized=false;
  var typeObjReceived="";
  var objectListKey=[];
  </script>
  <!-- /Set UP -->


  <!-- FIREBASE -->
  <script src="https://www.gstatic.com/firebasejs/3.5.3/firebase.js"></script>
  <script type="text/javascript">
  // Initialize Firebase
  var config = {
    apiKey: settings.apiKey,
    authDomain: settings.authDomain,
    databaseURL: settings.databaseURL,
    storageBucket: settings.storageBucket,
    messagingSenderId: settings.messagingSenderId
  };
  firebase.initializeApp(config);

  //Check login status
  firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
      // User is signed in.
        console.log("User is signed in.");
        $('.theUser').html(user.email);
    } else {
      // No user is signed in.
        console.log("No user is signed in.");
        window.location.replace("login.php");
    }
  });

  </script>
  <!-- /FIREBASE -->

  <!-- Admin scripts -->
  <script src="js/admin.js"></script>

  <!-- Plural scripts -->
  <script src="js/plural.js"></script>


    <script>
      /*
      *
      *  JQUERY Start
      *
      */
      $( document ).ready(function() {

        //Start the firebase fetcher
        getDataFromFirbase();

        //New elements
        $('#addItem').on('click',function(){
          console.log("add");
          $(".newFieldLoaderID").addClass('loaderSmall');
          writeTFData($('#newFieldName').val(),$('#newFieldValue').val())

        })

        //Sign out
        $('#logoutBtn').on('click',function(){
          console.log("Logout");
          signOut();

        })

        //Breadcrumbs
        $('.breadcrumbs').show();
      });
    </script>

  </body>
</html>
